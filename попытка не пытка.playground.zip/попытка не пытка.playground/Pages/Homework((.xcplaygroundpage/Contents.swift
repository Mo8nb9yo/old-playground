//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)


//Lesson 9

class Student {
    var name: String
    var classNumber: Int
    var grade: String
    
    init(name: String, classNumber: Int, grade: String){
        self.name = name
        self.classNumber = classNumber
        self.grade = grade
    }
}

var Student1 = Student(name: "Kinder", classNumber: 11, grade: "A")

var Student2 = Student(name: "Junko", classNumber: 10, grade: "C")

var Student3 = Student(name: "Daniel", classNumber: 7, grade: "F")

var Students: [Student] = [Student1, Student2, Student3]

//Lesson 10

enum Weekdays {
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
}
print(Weekdays.monday)

var Tasks: [Weekdays: [String]] = [
        .monday: ["take a shower, make dinner?"],
        .tuesday: ["go to shooping, clear work space?"],
        .wednesday: ["take a bath, clean bedroom?"],
        .thursday: ["make a bed, go for a walk?"],
        .friday: ["suiqide."]
                   ]
let today: Weekdays = .friday

switch today {
case .monday:
    print(Tasks[.monday]!)
case .tuesday:
    print(Tasks[.tuesday]!)
case .wednesday:
    print(Tasks[.wednesday]!)
case .thursday:
    print(Tasks[.thursday]!)
case .friday:
    print(Tasks[.friday]!)
}

print(today)
