import UIKit
// lesson 1
//Variable
var greeting = "Hello, playground"
//Constant
var constantnumber: Int = 10
constantnumber = 11

print(constantnumber)

var 🏳️‍🌈: String = "Test"

var age: Int
age = 45

print(age)

// comment
/* Moonie <3
 yea yea
*/
///lol

// string is text int is number

//Lesson 2

let name: String = "Moonie"
type(of: name)
//character
var char: Character = "H"
//string
var string: String = "Test String"
//integer
var int: Int = 89
//float
var FloatVar: Float = 8.9

print(FloatVar, FloatVar2)
var FloatVar2: Float = 8
//double
var DoubleNumber: Double = 50.89
//Boolean
var isTrue: Bool = true
let a = 5
let b = 6
let bool = a<b
print(bool)

//typealias
// int64
 typealias ExampleType = Int64

let number: ExampleType = 78

class CustomersTableViewControler {
    struct CustomerTableViewCell {
    }
}


//lesson 3
//operators and if statement

let userAge = 10
if userAge <= 18 {
    print("access allowed")
} else if userAge >= 14 {
    print("Acess denied")
} else {
    print("Ask parents first")
}

// Unary
// Binary
// Ternary


//BINARY
var num1 = 10
var num2 = 4
var num3: Int

num3 = num1+num2

// Comparision
print(num1==num2)

//Unary
num3 = -num2

//logical
//logicall not
//logicall AND
//logicall Or

//false and true
if (num1 <= num2) && (num1 < 20){
    print(true)
}
//false or true
if (num1 <= num2) || (num1 < 20){
    print(true)
}

//ternary

if userAge >= 18 {
    print("access allowed")
} else if userAge >= 14 {
    print("Acess denied")}


print(userAge >= 18 ? "acces allowed" : "access denied")

let numbersRange = 1...5
numbersRange.contains(4)

//lesson 4

//collection types
//ARRAY
//SET

// ARRAY
var integers: [Int] = []
var integers2 = Array(repeating: 1, count: 4)
var integers3 = Array(arrayLiteral: int)

integers.append(5)
print(integers)

var array2 = [4,7]
var array3: [String] = ["Moon", "Pluton","Venera"]
print(array3)

print(array3.count)
print(array3.isEmpty)

print(array3[2])
print(array3[0])

array3.insert("Earth", at: 0)
array3.removeLast(2)

// SET
var Letters = Set<Character>()
print(Letters.count)
Letters.insert("M")
Letters.insert("o")
Letters.insert("O")
Letters.insert("n")
print(Letters)
Letters.insert("n")
print(Letters)

var set: Set<String> = ["Moon","Hoho","lol"]

//.count .isEmpty .contains .remove
//.intersection .symmetricDifference .union .subtracking .isSubset

//lesson 5

//Loop
//Control Flow (if, guard, switch. loop: for-in, while, RANGE, etc.)
//FOR-IN
let users = ["user1", "Jonh", "Minnor"]
for user in users {
    print("Hello, \(user)!")
}

let usersAndAge = ["user1": 12, "Jonh": 18, "Minnor": 40]
for (userName, userAge) in usersAndAge {
    print("\(userName), congratilations now u \(userAge)")
}
//for numbers in 1...5{
    //....}
//while loop
var countdown = 10
while countdown > 0 {
    print("second left \(countdown)")
    countdown -= 1

}
print("happy death!")

//lesson 6

//dictionaries

//var userAndYearOfBirth: [String: Int] = [:] //[String] = []

var userAndYearOfBirth: [String: Int] = ["User1": 1999, "Milana": 2009, "Nuke": 1956]
print(userAndYearOfBirth.keys)
print(userAndYearOfBirth.values)

print(userAndYearOfBirth["User1"])
print(userAndYearOfBirth.count)
if !userAndYearOfBirth.isEmpty {
    print("kuki")
}
userAndYearOfBirth["User1"] = 1984
print(userAndYearOfBirth)

userAndYearOfBirth.updateValue(1765, forKey:"Nuke")
print(userAndYearOfBirth)

//for-in

for year in userAndYearOfBirth.values {
    print(year)
    
}

//Lesson 7
//Optionals

//nil

struct Users {
    var usersName: String? = nil
    var email: String = "Users@iCloud.com" }
//1. ! promise
//print(usersName!)

//usersName = "Book"
//print(usersName!)

//2. if let / guard let

//if let name = Users().usersName {
 //   print(name)
//} else { //...
    
//}


//guard let name2 = Users().usersName else {fatalError("Error")}

//. Chaining

let textField: UITextField? = UITextField()
textField?.text = "test"
print(textField?.text ?? "")

//4. ?? "" defolt

if Users().usersName == nil {
    print("GMfU")
} else {
    print(Users().usersName!)
}
 
//lesson 8
//Function........

//chunk of code
// SPecific task

func sayHello(userName: String, userCountry: String ) -> String {
    let greeting = "Hello, " + userName + " lox" + " from "
+ userCountry
    return greeting
}
let result = sayHello(userName: "moonie", userCountry: "Japan")
print(result)

//lesson 9

//Struct
//class

struct User {
    var name = "Andrew"
    var lastName = "Navarro"
    var age = 21
}
var Users1 = User()
var Users2 = Users1
print(Users1.name, Users2.name)

class Car {
    var Brand = "toyota"
    var year = 2025
    var price = 250
    init() {
        //
    }
}

var car1 = Car()
var car2 = car1
car2.Brand = "AUDI"
print(car1.Brand, car2.Brand )

//inheritance
//class NewCar: Car()

//check type at runtime
//Deinitialize
//struck (enum) = value
//class = reference type


var car = Car()


class Store {
    var name: String
    var year: Int
    var numberOfProducte: Int
    
    init(name: String, year: Int, numberOfProducte: Int) {
        self.name = name
        self.year = year
        self.numberOfProducte = numberOfProducte
    }
}

var store1 = Store(name: "Ikea", year: 1855, numberOfProducte: 1945)
var store2 = Store(name: "Novus", year: 1994, numberOfProducte: 637)

//Lesson 10
//Enum
//Enumiration

enum SummerMonths: String, CaseIterable {
    case june = "June"
   case July
  case August
}

var summerMonths = SummerMonths.July

switch summerMonths {
case .june:
    print("Hello Summer")
case .August:
    print("Bye Summer")
default:
    print("")
}


print(SummerMonths.june.rawValue)

//Lesson 11

